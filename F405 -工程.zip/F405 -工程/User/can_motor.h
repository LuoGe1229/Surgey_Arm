#ifndef CAN_MOTOR_H
#define CAN_MOTOR_H
#include "can.h"
#include "Function.h"
//������Ժ�
#define M3508_CURRENT_MAX   16384
#define M6020_CURRENT_MAX   6000
#define M2006_CURRENT_MAX   6000

#define MOTOR_MAX_NUM    8


typedef struct
{
    int16_t set_voltage;            //��ѹ
    uint16_t angle;                 //ת�ӽǶ� abs angle range:[0,8191]
    int16_t speed;                  //ת���ٶ�
    int16_t torque_current;         //Ť�أ��Ե���ֵΪ��λ��
    uint8_t temp;                   //����¶�
    int32_t total_angle;            //ת��ת�����ܽǶ�
    int16_t total_cnt;              //ת��ת������Ȧ��
    uint16_t offset_angle;          //�ϵ�ʱ��ת��λ�ã���ʼλ�ã�
    uint16_t last_angle;            //abs angle range:[0,8191]
    uint32_t msg_cnt;               //��Ϣ����ֵ���յ�һ�ξ�+1
    
    uint32_t J60_angle;             //J60����ԭʼ�������
    uint32_t J60_speed;
    uint16_t J60_torque;
    uint8_t J60_temp_flag;
    uint8_t J60_temperature;
      
}moto_info_t;

typedef struct
{   
    float J60_angle;             //J60����ԭʼ�������
    float J60_speed;
    float J60_torque;
    uint8_t J60_temp_flag;
    uint8_t J60_temperature;
    
  
}moto_info_J;

typedef struct
{
    int8_t target_angle;  //-40~40
    int8_t target_velocity;  //-40~40
    uint16_t Kp;  //0~1023
    uint8_t Kd;   //0~51
    int8_t target_torque; //-40~40
}J60_cmd;

typedef union
{
    uint8_t data_8[8];
    uint16_t data_uint16[4];
    int16_t data_int16[4];
    int32_t data_int[2];
    uint32_t data_uint[2];
    float data_f[2];
}union_64;

typedef union
{
    uint8_t data_8[4];
    uint16_t data_16[2];
    int32_t data_int;
    uint32_t data_uint;
    float data_f;
}union_32;


//ȫ�ֱ�������
extern moto_info_t motor_info[MOTOR_MAX_NUM];
extern float global_pos1;
extern float global_speed;
extern moto_info_t J60_motor[2];
extern J60_cmd J60_control[2];
extern moto_info_J J60_actual[2];

//�û���������

void set_current(CAN_HandleTypeDef *hcan, int16_t id_range, int16_t current1, int16_t current2, int16_t current3, int16_t current4);
void motor_info_record(moto_info_t *ptr, uint8_t *data);
void can_filter_init_recv_all(CAN_HandleTypeDef *_hcan);
void CANSendData(CAN_HandleTypeDef *hcan, uint8_t ID, uint8_t length, uint8_t *data);

void J60_ENABLE(CAN_HandleTypeDef *hcan,uint8_t motor_id);
void sendCANMessage(CAN_HandleTypeDef *hcan, uint8_t joint_id, J60_cmd *ptr); 
void J60_Init(CAN_HandleTypeDef *hcan,uint8_t motor_id,J60_cmd *ptr);
void J60_control_param(int8_t target_angle,int8_t target_velocity,uint16_t Kp,uint8_t Kd,int8_t target_torque,J60_cmd
    *ptr);
void J60_Get_actual(moto_info_t *ptr,moto_info_J *p);
void J60_DISABLE(CAN_HandleTypeDef *hcan,uint8_t motor_id);


#endif 
