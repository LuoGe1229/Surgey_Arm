#include "pid.h"
pid_type_def  pid_spd1 , pid_pos1;
//pid��ʼ��
void PID_init(pid_type_def *pid, uint8_t mode,  float Kp, float Ki, float Kd, float max_out, float max_iout, float integral_sep)
{
    pid->mode = mode;
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->max_out = max_out;
    pid->max_iout = max_iout;
    pid->integral_sep = integral_sep;
    pid->Dbuf = 0.0f;
    pid->error[0] = pid->error[1] = pid->error[2] = pid->Pout = pid->Iout = pid->Dout = pid->out = 0.0f;
}

//pid����
float PID_calc(pid_type_def *pid, float actual, float target)
{
    pid->error[2] = pid->error[1];
    pid->error[1] = pid->error[0];
    pid->error[0] = target - actual;

    if(pid->mode == PID_POSITION)
    {
        pid->Pout = pid->Kp * pid->error[0];
        //����ӻ��ַ���
        if(pid->integral_sep != 0)
        {
            if(ABS(pid->error[0])<pid->integral_sep)
            {
                pid->Iout += pid->Ki * pid->error[0];
            }
            else{

                pid->Iout=0;
            }
        }
        else
        {
            pid->Iout += pid->Ki * pid->error[0];
        }
        pid->Dbuf = pid->error[0] - pid->error[1];
        pid->Dout = pid->Kd * pid->Dbuf;
        LimitMax(pid->Iout, pid->max_iout);
        pid->out = pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);

    }
    else if (pid->mode == PID_Increment)
    {
        pid->Pout = pid->Kp * (pid->error[0] - pid->error[1]);
        pid->Iout = pid->Ki * pid->error[0];
        pid->Dbuf = (pid->error[0] - 2.0f * pid->error[1] + pid->error[2]);
        pid->Dout = pid->Kd * pid->Dbuf;
        pid->out += pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);
    }
    return pid->out;
}


// pid���
void PID_clear(pid_type_def *pid)
{
    if (pid == NULL)
    {
        return;
    }

    pid->error[0] = pid->error[1] = pid->error[2] = 0.0f;
    pid->Dbuf = 0.0f;
    pid->out = pid->Pout = pid->Iout = pid->Dout = 0.0f;
    pid->actual = pid->target = 0.0f;
}
