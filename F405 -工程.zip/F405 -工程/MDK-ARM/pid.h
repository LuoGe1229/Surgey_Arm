#ifndef PID_H
#define PID_H
#include "stm32f4xx.h"                  // Device header
#define pi 3.14159265359
#define LimitMax(input , max)  \
{                              \
        if (input > max)       \
        {                      \
            input = max;       \
        }                      \
        else if (input < -max) \
        {                      \
            input = -max;      \
        }                      \
                               \
}

#define ABS(x)	((x>0)? (x): -(x))

enum PID_MODE
{
    PID_POSITION = 0, //λ��ʽ
    PID_Increment  = 1  //����ʽ
};

typedef struct
{
    uint8_t mode;
    //PID ������
    float Kp;
    float Ki;
    float Kd;
    float index;
    float target;
    float actual;

    float Pout;
    float Iout;
    float Dout;
    float out;

    float max_out;  //������
    float max_iout; //���������
    float integral_sep; //���ַ������ֵ

    float Dbuf;  //΢����
    float error[3]; //����� 0���� 1��һ�� 2���ϴ�
    
    

} pid_type_def;

typedef struct {
    float Kp;
    float Ki;
    float Kd;
} PID_Params;

void PID_init(pid_type_def *pid, uint8_t mode,  float Kp, float Ki, float Kd, float max_out, float max_iout, float integral_sep);
extern float PID_calc(pid_type_def *pid, float actual, float target);
extern void PID_clear(pid_type_def *pid);
extern pid_type_def  pid_spd1 , pid_pos1, pid_spd2 , pid_pos2, pid_spd3 , pid_pos3;
extern PID_Params spd1 , pos1;
#endif //PID_H
