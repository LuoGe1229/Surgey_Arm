#ifndef __Function_H__
#define __Function_H__

#include "main.h"
#include "can_motor.h"



//typedef struct 
//{
//    
//float Joint_Angle1;
//float Joint_Angle2;
//    
//} Balance_Target;

typedef enum {
    Brake_OFF = 0,
    Brake_ON  = 1
} Brake_State;


typedef enum {
    Lock = 0,
    Balance  = 1,
    Free_Move  = 2,
    Step_Move = 3,   
} State_Flag;
//extern Balance_Target Balance_Position;
extern Brake_State BRAKE_STATE;
extern State_Flag State;

void AUTO_BALANCE(moto_info_t *J60_1,moto_info_t *J60_2);
void Free_Movement(void);
void Step_Mode(moto_info_t *J60_1,moto_info_t *J60_2);
void Brake(Brake_State BRAKE_STATE);
void M2006_Stiffness(moto_info_t *M2006_1,moto_info_t *M2006_2,uint8_t flag,uint16_t stop_point1,uint16_t stop_point2);
void Lockout(void);
State_Flag Mode_Set(uint8_t num);
void IDLE_Mode(void);

#endif 

