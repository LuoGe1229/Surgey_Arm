/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "Debug.h"
#include "can_motor.h"
#include "pid.h"
#include <stdlib.h>
#include <stdio.h>
#include "Function.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_CAN1_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_CAN2_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */
    CAN1_ConfigFilter();
    CAN2_ConfigFilter();
    PID_init(&pid_pos1,PID_POSITION,0.1f,0.0f,1.0f,1000,0,0);
    PID_init(&pid_spd1,PID_Increment,1.0f,0.1f,1.0f,M6020_CURRENT_MAX,0,0);
    PID_init(&pid_pos2,PID_POSITION,0.8f,0.0f,0.0f,3000,0,0);
    PID_init(&pid_spd2,PID_Increment,5.0f,0.1f,3.0f,M2006_CURRENT_MAX,0,0);
    PID_init(&pid_pos3,PID_POSITION,0.8f,0.0f,0.0f,3000,0,0);
    PID_init(&pid_spd3,PID_Increment,5.0f,0.1f,3.0f,M2006_CURRENT_MAX,0,0);
     HAL_UART_Receive_DMA(&huart2, &RxTemp, 1);
     HAL_UART_Receive_DMA(&huart1, &KeyFlag, 1);
//	int M6020_target = 10000;
//    int M2006_target = 0;
	int M2006_Out1 = 0;
//    int M2006_Out2 = 0;
//    int speed =100;
    int M6020_Out1 = 0;
    J60_Init(&hcan2,1,&J60_control[0]);
//    J60_DISABLE(&hcan1,1);
    Brake(Brake_OFF);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
//      M2006_Out1 = PID_calc(&pid_spd2,motor_info[0].speed,1500); 
////  M6020_Out1 = PID_calc(&pid_spd1,motor_info[4].speed,100); 
//	  set_current(&hcan1,0x200,(int16_t)M2006_Out1,0,0,0);
////      set_current(&hcan1,0x1fe,(int16_t)M6020_Out1,0,0,0);
//      printf("%d\n",motor_info[0].speed);
////      printf("hello\n");
//      J60_control_param(0x7000,0,0x10,0x10,0,&J60_control[0]);
//      sendCANMessage(&hcan2, 1, &J60_control[0]);
////      J60_Get_actual(&J60_motor[0],&J60_actual[0]);
////      printf("%.2f\n",J60_actual[0].J60_angle);
//      J60_ENABLE(&hcan2,1);
//       uint16_t angle1 = 0x7000;      
//       J60_control_param(angle1,0,0x100,0x10,0,&J60_control[0]);
//       sendCANMessage(&hcan2, 1, &J60_control[0]);
      
//      

      AUTO_BALANCE(&J60_motor[0],&J60_motor[1]);


//      Free_Movement();
//      Step_Mode(&J60_motor[0],&J60_motor[1]);
//      IDLE_Mode();


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
    
  while (1)
  {
      Lockout();
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

